export default function initApp() {
  console.log('InfraControl inicializado...');
}
